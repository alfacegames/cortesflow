# CorteFlow — Barbearia Dom Corte

Protótipo funcional desenvolvido com HTML5, CSS3 e JavaScript, com estrutura inicial de API REST em Java/Spring Boot.

## Executar a interface (mais simples)

1. Extraia o ZIP.
2. Abra `index.html` no Google Chrome, Edge ou Firefox.
3. Os dados da demonstração ficam no `localStorage` do navegador. Para reiniciar a demonstração, abra as ferramentas do navegador e limpe a chave `corteflow_db` do armazenamento local.

### Contas de demonstração

- **Administrador:** `admin@corteflow.com` / `admin123`
- **Cliente:** `joao@email.com` / `123456`
- **Barbeiro (Carlos Mendes):** `carlos@corteflow.com` / `barber123`
- **Barbeiro (Rafael Oliveira):** `rafael@corteflow.com` / `barber123`
- **Barbeiro (Lucas Ferreira):** `lucas@corteflow.com` / `barber123`

## Executar com Java / Spring Boot

Requisitos: JDK 17+ e Maven.

Na pasta do projeto, execute:

```bash
mvn spring-boot:run
```

Acesse `http://localhost:8080`. A API está disponível em `http://localhost:8080/api`.

Endpoints iniciais:

- `GET /api/health`
- `GET/POST /api/servicos`
- `PUT /api/servicos/{id}`
- `DELETE /api/servicos/{id}` (desativa)
- `GET/POST /api/barbeiros`
- `PUT /api/barbeiros/{id}`
- `DELETE /api/barbeiros/{id}` (desativa)
- `GET/POST /api/clientes`
- `GET/POST /api/agendamentos`
- `PATCH /api/agendamentos/{id}/status`

## O que já funciona no protótipo

- Landing page com serviços e identidade visual inspirada nas telas do PDF.
- Cadastro, login de demonstração e recuperação de senha demonstrativa.
- Área do cliente, dashboard, perfil, alteração de senha, histórico e lista de agendamentos.
- Área exclusiva do barbeiro: login por profissional, agenda individual, atualização do status dos próprios atendimentos e configuração dos dias/horários de turno.
- Fluxo de agendamento por serviço, barbeiro, data, horário e confirmação.
- Verificação de disponibilidade com base na duração do serviço e nos horários ocupados.
- Cancelamento e alteração de agendamentos.
- Painel administrativo, agenda, status dos atendimentos, clientes, serviços, barbeiros e configurações.
- Layout responsivo para computador, tablet e celular.
- Persistência local no navegador e API Java inicial com armazenamento em memória.

## Limitações importantes

- O modo aberto diretamente no navegador é uma demonstração local: o `localStorage` não sincroniza dados entre dispositivos ou navegadores.
- A API Java mantém os dados apenas em memória, então os dados se perdem ao reiniciar o servidor.
- As credenciais e regras de autenticação do frontend são somente para demonstração; não utilizar em produção sem autenticação segura, controle de permissões no backend, hash de senhas, persistência apropriada e validações adicionais.
- O fluxo visual do frontend usa `localStorage`; a API Java está incluída como base de integração, mas ainda não está conectada automaticamente ao frontend.
- As fotografias de fundo usam imagens remotas e precisam de conexão com a internet para aparecer.
