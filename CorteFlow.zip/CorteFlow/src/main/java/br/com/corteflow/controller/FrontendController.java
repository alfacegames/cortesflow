package br.com.corteflow.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FrontendController {
    @GetMapping({"/", "/app"})
    public String index() { return "forward:/index.html"; }
}
