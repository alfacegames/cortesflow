package br.com.corteflow.service;

import br.com.corteflow.model.*;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ArmazenamentoMemoria {
    public final Map<String, Cliente> clientes = new ConcurrentHashMap<>();
    public final Map<String, Barbeiro> barbeiros = new ConcurrentHashMap<>();
    public final Map<String, Servico> servicos = new ConcurrentHashMap<>();
    public final Map<String, Agendamento> agendamentos = new ConcurrentHashMap<>();
    public ArmazenamentoMemoria() {
        servicos.put("s1", new Servico("s1","Corte Masculino","Corte tradicional, lavagem e finalização.",45,45));
        servicos.put("s2", new Servico("s2","Barba","Alinhamento, tosa e hidratação da barba.",30,35));
        servicos.put("s3", new Servico("s3","Corte + Barba","Pacote completo de cabelo e barba.",75,70));
        servicos.put("s4", new Servico("s4","Sobrancelha","Acabamento preciso.",15,20));
        barbeiros.put("b1", new Barbeiro("b1","Carlos Mendes","Especialista em cortes masculinos",""));
        barbeiros.put("b2", new Barbeiro("b2","Rafael Oliveira","Especialista em barba e acabamento",""));
        barbeiros.put("b3", new Barbeiro("b3","Lucas Ferreira","Especialista em cortes modernos",""));
    }
}
