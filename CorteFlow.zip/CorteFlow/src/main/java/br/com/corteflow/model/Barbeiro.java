package br.com.corteflow.model;

public class Barbeiro {
    private String id, nome, especialidade, telefone;
    private boolean ativo = true;
    public Barbeiro() {}
    public Barbeiro(String id, String nome, String especialidade, String telefone) { this.id=id; this.nome=nome; this.especialidade=especialidade; this.telefone=telefone; }
    public String getId(){return id;} public void setId(String v){id=v;}
    public String getNome(){return nome;} public void setNome(String v){nome=v;}
    public String getEspecialidade(){return especialidade;} public void setEspecialidade(String v){especialidade=v;}
    public String getTelefone(){return telefone;} public void setTelefone(String v){telefone=v;}
    public boolean isAtivo(){return ativo;} public void setAtivo(boolean v){ativo=v;}
}
