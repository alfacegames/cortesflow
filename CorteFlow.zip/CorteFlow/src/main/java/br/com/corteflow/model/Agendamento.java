package br.com.corteflow.model;

import java.time.LocalDate;

public class Agendamento {
    private String id, clienteId, servicoId, barbeiroId, horario, status = "Agendado";
    private LocalDate data;
    public Agendamento() {}
    public String getId(){return id;} public void setId(String v){id=v;}
    public String getClienteId(){return clienteId;} public void setClienteId(String v){clienteId=v;}
    public String getServicoId(){return servicoId;} public void setServicoId(String v){servicoId=v;}
    public String getBarbeiroId(){return barbeiroId;} public void setBarbeiroId(String v){barbeiroId=v;}
    public String getHorario(){return horario;} public void setHorario(String v){horario=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public LocalDate getData(){return data;} public void setData(LocalDate v){data=v;}
}
