package br.com.corteflow.model;

public class Servico {
    private String id, nome, descricao;
    private int duracaoMinutos;
    private double valor;
    private boolean ativo = true;
    public Servico() {}
    public Servico(String id, String nome, String descricao, int duracaoMinutos, double valor) { this.id=id; this.nome=nome; this.descricao=descricao; this.duracaoMinutos=duracaoMinutos; this.valor=valor; }
    public String getId(){return id;} public void setId(String v){id=v;}
    public String getNome(){return nome;} public void setNome(String v){nome=v;}
    public String getDescricao(){return descricao;} public void setDescricao(String v){descricao=v;}
    public int getDuracaoMinutos(){return duracaoMinutos;} public void setDuracaoMinutos(int v){duracaoMinutos=v;}
    public double getValor(){return valor;} public void setValor(double v){valor=v;}
    public boolean isAtivo(){return ativo;} public void setAtivo(boolean v){ativo=v;}
}
