package br.com.corteflow.model;

public class Cliente {
    private String id, nome, email, telefone;
    public Cliente() {}
    public Cliente(String id, String nome, String email, String telefone) { this.id=id; this.nome=nome; this.email=email; this.telefone=telefone; }
    public String getId(){return id;} public void setId(String v){id=v;}
    public String getNome(){return nome;} public void setNome(String v){nome=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getTelefone(){return telefone;} public void setTelefone(String v){telefone=v;}
}
