package br.com.corteflow.controller;

import br.com.corteflow.model.*;
import br.com.corteflow.service.ArmazenamentoMemoria;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final ArmazenamentoMemoria db;
    public ApiController(ArmazenamentoMemoria db){this.db=db;}
    @GetMapping("/health") public Map<String,String> health(){return Map.of("status","ok","app","CorteFlow");}
    @GetMapping("/servicos") public Collection<Servico> servicos(){return db.servicos.values();}
    @PostMapping("/servicos") public Servico criarServico(@RequestBody Servico s){if(s.getId()==null||s.getId().isBlank())s.setId(UUID.randomUUID().toString());db.servicos.put(s.getId(),s);return s;}
    @PutMapping("/servicos/{id}") public Servico editarServico(@PathVariable String id,@RequestBody Servico s){if(!db.servicos.containsKey(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND);s.setId(id);db.servicos.put(id,s);return s;}
    @DeleteMapping("/servicos/{id}") public Map<String,String> desativarServico(@PathVariable String id){Servico s=db.servicos.get(id);if(s==null)throw new ResponseStatusException(HttpStatus.NOT_FOUND);s.setAtivo(false);return Map.of("mensagem","Serviço desativado");}
    @GetMapping("/barbeiros") public Collection<Barbeiro> barbeiros(){return db.barbeiros.values();}
    @PostMapping("/barbeiros") public Barbeiro criarBarbeiro(@RequestBody Barbeiro b){if(b.getId()==null||b.getId().isBlank())b.setId(UUID.randomUUID().toString());db.barbeiros.put(b.getId(),b);return b;}
    @PutMapping("/barbeiros/{id}") public Barbeiro editarBarbeiro(@PathVariable String id,@RequestBody Barbeiro b){if(!db.barbeiros.containsKey(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND);b.setId(id);db.barbeiros.put(id,b);return b;}
    @DeleteMapping("/barbeiros/{id}") public Map<String,String> desativarBarbeiro(@PathVariable String id){Barbeiro b=db.barbeiros.get(id);if(b==null)throw new ResponseStatusException(HttpStatus.NOT_FOUND);b.setAtivo(false);return Map.of("mensagem","Barbeiro desativado");}
    @GetMapping("/clientes") public Collection<Cliente> clientes(){return db.clientes.values();}
    @PostMapping("/clientes") public Cliente criarCliente(@RequestBody Cliente c){if(c.getId()==null||c.getId().isBlank())c.setId(UUID.randomUUID().toString());db.clientes.put(c.getId(),c);return c;}
    @GetMapping("/agendamentos") public Collection<Agendamento> agendamentos(){return db.agendamentos.values();}
    @PostMapping("/agendamentos") public Agendamento criarAgendamento(@RequestBody Agendamento a){
        if(!db.clientes.containsKey(a.getClienteId()))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Cliente inválido");
        Servico s=db.servicos.get(a.getServicoId()); if(s==null||!s.isAtivo())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Serviço inválido");
        Barbeiro b=db.barbeiros.get(a.getBarbeiroId());if(b==null||!b.isAtivo())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Barbeiro inválido");
        boolean conflito=db.agendamentos.values().stream().anyMatch(x->x.getBarbeiroId().equals(a.getBarbeiroId())&&x.getData().equals(a.getData())&&x.getHorario().equals(a.getHorario())&&!"Cancelado".equals(x.getStatus()));
        if(conflito)throw new ResponseStatusException(HttpStatus.CONFLICT,"Horário ocupado");
        if(a.getId()==null||a.getId().isBlank())a.setId(UUID.randomUUID().toString());if(a.getStatus()==null)a.setStatus("Agendado");db.agendamentos.put(a.getId(),a);return a;
    }
    @PatchMapping("/agendamentos/{id}/status") public Agendamento status(@PathVariable String id,@RequestBody Map<String,String> body){Agendamento a=db.agendamentos.get(id);if(a==null)throw new ResponseStatusException(HttpStatus.NOT_FOUND);String s=body.get("status");if(!Set.of("Agendado","Confirmado","Concluído","Cancelado").contains(s))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Status inválido");a.setStatus(s);return a;}
}
